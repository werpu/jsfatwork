package at.irian.jsfatwork.gui.page;

import at.irian.jsfatwork.domain.Provider;
import at.irian.jsfatwork.gui.util.GuiUtil;
import at.irian.jsfatwork.service.ProviderService;
import org.springframework.context.annotation.Scope;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ComponentSystemEvent;
import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.constraints.Min;

@Named("providerBean")
@Scope("view")
public class ProviderBean {

    @Inject
    private ProviderService providerService;

    @Min(value = 0)
    private long id;
    private Provider provider;

    public void preRenderView(@SuppressWarnings("UnusedParameters") ComponentSystemEvent ev) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        if (!ctx.isValidationFailed()) {
            provider = providerService.findById(id);
            if (provider == null) {
                ctx.addMessage(null,
                        GuiUtil.getFacesMessage(ctx, FacesMessage.SEVERITY_ERROR, "error_non_existing_provider", id)
                );
            }
        }
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Provider getProvider() {
        return provider;
    }

    public String save() {
        return "showProvider?faces-redirect=true&includeViewParams=true";
    }

    @SuppressWarnings("UnusedDeclaration")
    public void setProviderService(ProviderService providerService) {
        this.providerService = providerService;
    }

}
