package at.irian.jsfatwork.gui.page;

import at.irian.jsfatwork.domain.Provider;
import at.irian.jsfatwork.mygourmet.GuiUtil;
import at.irian.jsfatwork.service.ProviderService;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ComponentSystemEvent;
import javax.validation.constraints.Min;

@ManagedBean
@ViewScoped
public class ProviderBean {

    @Min(value = 0)
    private long id;
    private Provider provider;
    @ManagedProperty(value = "#{providerService}")
    private ProviderService providerService;

    public void preRenderView(@SuppressWarnings("UnusedParameters") ComponentSystemEvent ev) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        if (!ctx.isValidationFailed()) {
            provider = providerService.findById(id);
            if (provider == null) {
                ctx.addMessage(null,
                        GuiUtil.getFacesMessage(ctx, FacesMessage.SEVERITY_ERROR, "error_non_existing_provider", id)
                );
            }
        }
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Provider getProvider() {
        return provider;
    }

    public String save() {
        return "showProvider?faces-redirect=true&includeViewParams=true";
    }

    @SuppressWarnings("UnusedDeclaration")
    public void setProviderService(ProviderService providerService) {
        this.providerService = providerService;
    }

}
