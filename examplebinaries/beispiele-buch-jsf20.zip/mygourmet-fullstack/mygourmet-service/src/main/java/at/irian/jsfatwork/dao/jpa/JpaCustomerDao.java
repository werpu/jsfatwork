package at.irian.jsfatwork.dao.jpa;

import at.irian.jsfatwork.dao.CustomerDao;
import at.irian.jsfatwork.domain.Customer;

import javax.inject.Named;
import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Named("customerDao")
@Singleton
public class JpaCustomerDao implements CustomerDao {

    @PersistenceContext
    private EntityManager em;

    public Customer createNew() {
        Customer customer = new Customer();
        return customer;
    }

    public void persist(Customer customer) {
        em.persist(customer);
    }

    @SuppressWarnings({"unchecked"})
    public List<Customer> findAll() {
        return em.createQuery("select c from Customer c").getResultList();
    }

    public Customer findById(long id) {
        return em.find(Customer.class, id);
    }

    public void delete(Customer customer) {
        em.remove(customer);
    }

}
