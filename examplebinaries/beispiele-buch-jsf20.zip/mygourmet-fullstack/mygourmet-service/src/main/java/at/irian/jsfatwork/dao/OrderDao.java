package at.irian.jsfatwork.dao;

import at.irian.jsfatwork.domain.Order;

public interface OrderDao extends BaseDao<Order> {
}
