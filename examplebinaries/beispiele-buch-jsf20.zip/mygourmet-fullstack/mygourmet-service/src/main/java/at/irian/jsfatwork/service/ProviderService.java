package at.irian.jsfatwork.service;

import at.irian.jsfatwork.domain.Provider;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

public interface ProviderService extends BaseService<Provider> {

    Provider createNew();

    void save(Provider entity);

    void delete(Provider entity);

    List<Provider> findAll();

    Provider findById(long id);

}
