package at.irian.jsfatwork.dao;

import at.irian.jsfatwork.domain.Dish;

public interface DishDao extends BaseDao<Dish> {

}
