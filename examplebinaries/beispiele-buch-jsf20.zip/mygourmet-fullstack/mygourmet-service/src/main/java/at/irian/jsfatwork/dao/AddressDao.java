package at.irian.jsfatwork.dao;

import at.irian.jsfatwork.domain.Address;

public interface AddressDao extends BaseDao<Address> {
}
