package at.irian.jsfatwork.domain;

public enum CreditCardType {
    CARD_A, CARD_B
}
