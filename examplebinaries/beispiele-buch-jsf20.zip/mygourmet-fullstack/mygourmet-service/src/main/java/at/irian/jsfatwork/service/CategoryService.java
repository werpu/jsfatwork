package at.irian.jsfatwork.service;

import at.irian.jsfatwork.domain.Category;

public interface CategoryService extends BaseService<Category> {

}
