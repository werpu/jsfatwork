package at.irian.jsfatwork.dao.jpa;

import at.irian.jsfatwork.dao.AddressDao;
import at.irian.jsfatwork.domain.Address;

import javax.inject.Named;
import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Named("addressDao")
@Singleton
public class JpaAddressDao implements AddressDao {

    @PersistenceContext
    private EntityManager em;

    public Address createNew() {
        return new Address();
    }

    public void persist(Address address) {
        em.persist(address);
    }

    @SuppressWarnings({"unchecked"})
    public List<Address> findAll() {
        return em.createQuery("select a from Address a").getResultList();
    }

    public Address findById(long id) {
        return em.find(Address.class, id);
    }

    public void delete(Address address) {
        em.remove(address);
    }

}
