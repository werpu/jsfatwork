package at.irian.jsfatwork.dao;

import at.irian.jsfatwork.domain.BaseEntity;

import java.util.List;

public interface BaseDao<T extends BaseEntity> {

    T createNew();
    
    void persist(T entity);

    List<T> findAll();

    T findById(long id);

    void delete(T entity);

}
