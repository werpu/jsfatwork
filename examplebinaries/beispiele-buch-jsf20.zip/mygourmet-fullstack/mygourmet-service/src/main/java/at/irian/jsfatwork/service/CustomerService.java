package at.irian.jsfatwork.service;

import at.irian.jsfatwork.domain.Customer;
import at.irian.jsfatwork.domain.Address;
import at.irian.jsfatwork.domain.Order;

public interface CustomerService extends BaseService<Customer> {

    Address createAddress(Customer customer);

    void saveAddress(Address address);

    void deleteAddress(Address address);

    Order createOrder(Customer customer);
    
    void saveOrder(Order order);

}
