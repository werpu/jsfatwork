package at.irian.jsfatwork.service.impl;

import at.irian.jsfatwork.dao.CategoryDao;
import at.irian.jsfatwork.domain.Category;
import at.irian.jsfatwork.service.CategoryService;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import java.util.List;

@Named("categoryService")
@Singleton
public class CategoryServiceImpl implements CategoryService {

    @Inject
    private CategoryDao categoryDao;

    public Category createNew() {
        return categoryDao.createNew();
    }

    @Transactional
    public void save(Category category) {
        categoryDao.persist(category);
    }

    @Transactional
    public void delete(Category entity) {
    }

    @Transactional(readOnly = true)
    public List<Category> findAll() {
        return categoryDao.findAll();
    }

    @Transactional(readOnly = true)
    public Category findById(long id) {
        return categoryDao.findById(id);
    }
}
