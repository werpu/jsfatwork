package at.irian.jsfatwork.dao;

import at.irian.jsfatwork.domain.Category;

public interface CategoryDao extends BaseDao<Category> {
}
