package at.irian.jsfatwork.dao;

import at.irian.jsfatwork.domain.Customer;

public interface CustomerDao extends BaseDao<Customer> {
}
