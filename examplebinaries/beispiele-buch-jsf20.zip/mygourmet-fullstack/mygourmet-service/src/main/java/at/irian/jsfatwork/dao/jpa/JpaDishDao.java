package at.irian.jsfatwork.dao.jpa;

import at.irian.jsfatwork.dao.DishDao;
import at.irian.jsfatwork.domain.Dish;

import javax.inject.Named;
import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Named("dishDao")
@Singleton
public class JpaDishDao implements DishDao {

    @PersistenceContext
    private EntityManager em;

    public Dish createNew() {
        return new Dish();
    }

    public void persist(Dish dish) {
        em.persist(dish);
    }

    @SuppressWarnings({"unchecked"})
    public List<Dish> findAll() {
        return em.createQuery("select d from Dish d").getResultList();
    }

    public Dish findById(long id) {
        return em.find(Dish.class, id);
    }

    public void delete(Dish dish) {
        em.remove(dish);
    }

}
