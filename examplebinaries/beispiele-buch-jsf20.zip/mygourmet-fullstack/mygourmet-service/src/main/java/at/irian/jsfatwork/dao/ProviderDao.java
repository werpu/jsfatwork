package at.irian.jsfatwork.dao;

import at.irian.jsfatwork.domain.Provider;

public interface ProviderDao extends BaseDao<Provider> {

}
