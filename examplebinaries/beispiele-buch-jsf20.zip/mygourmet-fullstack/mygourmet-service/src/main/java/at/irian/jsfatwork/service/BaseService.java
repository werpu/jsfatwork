package at.irian.jsfatwork.service;

import at.irian.jsfatwork.domain.Provider;

import java.util.List;

public interface BaseService<T> {

    T createNew();

    void save(T entity);

    void delete(T entity);

    List<T> findAll();

    T findById(long id);

}
