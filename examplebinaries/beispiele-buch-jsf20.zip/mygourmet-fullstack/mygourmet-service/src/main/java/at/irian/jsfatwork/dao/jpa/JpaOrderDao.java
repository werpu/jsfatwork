package at.irian.jsfatwork.dao.jpa;

import at.irian.jsfatwork.dao.OrderDao;
import at.irian.jsfatwork.domain.Order;

import javax.inject.Named;
import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Named("orderDao")
@Singleton
public class JpaOrderDao implements OrderDao {

    @PersistenceContext
    private EntityManager em;

    public Order createNew() {
        return new Order();
    }

    public void persist(Order order) {
        em.persist(order);
    }

    @SuppressWarnings({"unchecked"})
    public List<Order> findAll() {
        return em.createQuery("select order from Order order").getResultList();
    }

    public Order findById(long id) {
        return em.find(Order.class, id);
    }

    public void delete(Order order) {
        em.remove(order);
    }

}
