package at.irian.jsfatwork.domain;

public interface BaseEntity {

    Long getId();

    boolean isTransient();

}
