package at.irian.jsfatwork.gui.page;

import at.irian.jsfatwork.domain.*;
import at.irian.jsfatwork.gui.util.GuiUtil;
import at.irian.jsfatwork.service.CustomerService;
import at.irian.jsfatwork.service.ProviderService;
import org.apache.myfaces.orchestra.conversation.Conversation;
import org.apache.myfaces.orchestra.conversation.annotations.ConversationRequire;
import org.apache.myfaces.orchestra.viewController.annotations.PreRenderView;
import org.apache.myfaces.orchestra.viewController.annotations.ViewController;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.context.annotation.Scope;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

@Named("orderBean")
@Scope("manual")
@ViewController(viewIds = {ViewIds.ORDER_PROVIDER, ViewIds.ORDER_DISHES, ViewIds.ORDER_FINISH})
@ConversationRequire(conversationNames = "orderBean", entryPointViewIds = ViewIds.ORDER_PROVIDER,
        navigationAction = ViewIds.ORDER_PROVIDER)
public class OrderBean implements BeanFactoryAware {

    @Inject
    private CustomerService customerService;
    @Inject
    private ProviderService providerService;

    private BeanFactory beanFactory;
    private Order order;
    private Provider provider;
    private List<Provider> providers;
    private List<SelectableDish> dishes;

    @PreRenderView
    public void preRenderView() {
        providers = providerService.findAll();
    }

    public String start(long customerId) {
        Customer customer = customerService.findById(customerId);
        order = customerService.createOrder(customer);
        return ViewIds.ORDER_PROVIDER;
    }

    public String gotoDishes() {
        dishes = initSelectableDishes();
        order.setProvider(provider);
        return ViewIds.ORDER_DISHES;
    }

    public String gotoFinish() {
        if (!createOrderItems()) {
            FacesContext ctx = FacesContext.getCurrentInstance();
            FacesMessage msg = GuiUtil.getFacesMessage(ctx, FacesMessage.SEVERITY_ERROR, "error_no_dishes");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return null;
        }
        dishes = initSelectableDishes();
        return ViewIds.ORDER_FINISH;
    }

    private boolean createOrderItems() {
        boolean containsItem = false;
        for (SelectableDish dish : dishes) {
            if (dish.isSelected() && dish.getAmount() != null) {
                OrderItem item = new OrderItem();
                item.setDish(dish.getDish());
                item.setAmount(dish.getAmount());
                order.addOrderItem(item);
                containsItem = true;
            }
        }
        return containsItem;
    }

    public String finish() {
        customerService.saveOrder(order);
        Conversation.getCurrentInstance().invalidate();
        CustomerBean bean = (CustomerBean)beanFactory.getBean("customerBean");
        return bean.showCustomer(order.getCustomer().getId());
    }

    public String cancel() {
        Conversation.getCurrentInstance().invalidate();
        CustomerBean bean = (CustomerBean)beanFactory.getBean("customerBean");
        return bean.showCustomer(order.getCustomer().getId());
    }

    public Order getOrder() {
        return order;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public List<Provider> getProviders() {
        return providers;
    }

    public List<SelectableDish> getDishes() {
        return dishes;
    }

    private List<SelectableDish> initSelectableDishes() {
        List<SelectableDish> list = null;
        if (provider != null && this.dishes == null) {
            list = new ArrayList<SelectableDish>();
            for (Dish dish : provider.getDishes()) {
                list.add(new SelectableDish(dish));
            }
        }
        return list;
    }

    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

}
