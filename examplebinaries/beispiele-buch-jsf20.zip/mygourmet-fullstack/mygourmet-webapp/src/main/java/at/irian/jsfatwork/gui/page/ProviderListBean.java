package at.irian.jsfatwork.gui.page;

import at.irian.jsfatwork.domain.Provider;
import at.irian.jsfatwork.service.ProviderService;
import org.apache.myfaces.orchestra.viewController.annotations.PreRenderView;
import org.apache.myfaces.orchestra.viewController.annotations.ViewController;
import org.springframework.context.annotation.Scope;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Named("providerListBean")
@Scope("access")
@ViewController(viewIds = ViewIds.PROVIDER_LIST)
public class ProviderListBean {

    @Inject
    private ProviderService providerService;

    private List<Provider> providerList;

    @SuppressWarnings("UnusedDeclaration")
    @PreRenderView
    public void preRenderView() {
        providerList = providerService.findAll();
    }

    public List<Provider> getProviderList() {
        return providerList;
    }

    public String deleteProvider(Provider provider) {
        providerService.delete(provider);
        return null;
    }

}
