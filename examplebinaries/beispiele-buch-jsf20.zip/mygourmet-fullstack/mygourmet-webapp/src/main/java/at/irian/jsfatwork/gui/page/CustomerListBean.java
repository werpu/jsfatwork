package at.irian.jsfatwork.gui.page;

import at.irian.jsfatwork.domain.Customer;
import at.irian.jsfatwork.service.CustomerService;
import org.apache.myfaces.orchestra.viewController.annotations.PreRenderView;
import org.apache.myfaces.orchestra.viewController.annotations.ViewController;
import org.springframework.context.annotation.Scope;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Named("customerListBean")
@Scope("access")
@ViewController(viewIds = {ViewIds.CUSTOMER_LIST})
public class CustomerListBean {

    private List<Customer> customerList;
    @Inject
    private CustomerService customerService;

    @PreRenderView
    public void preRenderView() {
        customerList = customerService.findAll();
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public String deleteCustomer(Customer customer) {
        customerService.delete(customer);
        return null;
    }
    
}
