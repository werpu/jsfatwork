package at.irian.jsfatwork.tobago.ui;

import at.irian.jsfatwork.domain.Category;
import at.irian.jsfatwork.domain.Provider;
import at.irian.jsfatwork.service.CategoryService;
import at.irian.jsfatwork.service.ProviderService;
import org.apache.myfaces.orchestra.viewController.annotations.PreRenderView;
import org.apache.myfaces.orchestra.viewController.annotations.ViewController;
import org.apache.myfaces.tobago.model.SheetState;
import org.springframework.context.annotation.Scope;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created 25.08.2009 14:02:56
 */

@Named("providerController")
@Scope("access")
@ViewController(viewIds = {"/provider.xhtml", "/provider-list.xhtml"})
public class ProviderController {

    private static final String PROVIDER_LIST = "provider-list";
    private static final String PROVIDER = "provider";

    private List<Provider> providerList = new ArrayList<Provider>();
    private SheetState selectedProvider;
    private Provider provider;
    private List<SelectItem> categoryItems;

    @Inject
    private CategoryService categoryService;
    @Inject
    private ProviderService providerService;

    @PostConstruct
    private void init() {
        // Initialize categoryItems select items
        List<Category> cats = categoryService.findAll();
        categoryItems = new ArrayList<SelectItem>(cats.size());
        for (Category cat : cats) {
            categoryItems.add(new SelectItem(cat, cat.getName()));
        }
    }

    @PreRenderView
    public void loadProviderList() {
        providerList = providerService.findAll();
    }

    public String select(int stars) {
        provider.setStars(stars);
        return null;
    }

    public String select0() {
        return select(0);
    }

    public String select1() {
        return select(1);
    }

    public String select2() {
        return select(2);
    }

    public String select3() {
        return select(3);
    }

    public String select4() {
        return select(4);
    }

    public String select5() {
        return select(5);
    }

    public List<Provider> getProviderList() {
        return providerList;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public SheetState getSelectedProvider() {
        return selectedProvider;
    }

    public void setSelectedProvider(SheetState selectedProvider) {
        this.selectedProvider = selectedProvider;
    }

    public List<SelectItem> getCategoryItems() {
        return categoryItems;
    }

    public void setProviderCategories(List<Category> categories) {
        Set<Category> set = new HashSet<Category>();
        set.addAll(categories);
        provider.setCategories(set);
    }

    public List<Category>  getProviderCategories() {
        List<Category> list = new ArrayList<Category>();
        list.addAll(provider.getCategories());
        return list;
    }

    public String createProvider() {
        this.provider = providerService.createNew();
        return PROVIDER;
    }

    public String editProvider() {
        provider = getSingleSelectedProvider();
        if (provider != null) {
            provider = providerService.findById(provider.getId());
            return PROVIDER;
        } else {
            return PROVIDER_LIST;
        }
    }

    public String deleteProvider() {
        Provider p = getSingleSelectedProvider();
        if (p != null) {
            p = providerService.findById(p.getId());
            providerService.delete(p);
        }
        return null;
    }

    public String saveProvider() {
        providerService.save(provider);
        return PROVIDER_LIST;
    }

    public String cancel() {
        return PROVIDER_LIST;
    }

    private Provider getSingleSelectedProvider() {
        List<Integer> selection = selectedProvider.getSelectedRows();
        if (selection.size() != 1) {
          FacesMessage error = new FacesMessage("Please select exactly one row.");
          FacesContext.getCurrentInstance().addMessage(null, error);
            return null;
        }
        return providerList.get(selection.get(0));
    }

}