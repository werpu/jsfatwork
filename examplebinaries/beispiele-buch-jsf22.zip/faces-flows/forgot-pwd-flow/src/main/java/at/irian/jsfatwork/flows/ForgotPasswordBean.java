package at.irian.jsfatwork.flows;

import javax.faces.flow.FlowScoped;
import javax.inject.Named;
import java.io.Serializable;

@Named
@FlowScoped("forgotPassword")
public class ForgotPasswordBean implements Serializable {
}
