package at.irian.jsfatwork.tobago.ui;

import at.irian.jsfatwork.domain.Address;
import at.irian.jsfatwork.domain.Category;
import at.irian.jsfatwork.domain.CreditCardType;
import at.irian.jsfatwork.domain.Customer;
import at.irian.jsfatwork.gui.util.GuiUtil;
import at.irian.jsfatwork.service.CategoryService;
import at.irian.jsfatwork.service.CustomerService;
import org.apache.myfaces.orchestra.viewController.annotations.ViewController;
import org.apache.myfaces.tobago.model.SheetState;
import org.springframework.context.annotation.Scope;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * Created 25.08.2009 14:02:56
 */

@Named("customerController")
@Scope("access")
@ViewController(viewIds = {"/customer.xhtml", "/customer-list.xhtml"})
public class CustomerController {

    private final String CUSTOMER = "customer";
    private final String CUSTOMER_LIST = "customer-list";
    private final String ADDRESS = "address";

    private List<Customer> customerList;
    private Customer newCustomer = new Customer();
    private SheetState selectedCustomer;
    private SheetState selectedAddress;

    private Customer customer = new Customer();
    private List<SelectItem> ccTypes;
    private List<SelectItem> genderItems;
    private List<SelectItem> categories;
    private UIInput creditCardTypeInput = null;
    private boolean collapsed;
    private Address address;

    @Inject
    private CustomerService customerService;
    @Inject
    private CategoryService categoryService;

    private List<Address> addressList = new ArrayList<Address>();

    @PostConstruct
    private void init() {
        // Initialize credit card type select items
        this.ccTypes = new ArrayList<SelectItem>();
        this.ccTypes.add(new SelectItem(CreditCardType.CARD_A, getCCTypeLabel(CreditCardType.CARD_A)));
        this.ccTypes.add(new SelectItem(CreditCardType.CARD_B, getCCTypeLabel(CreditCardType.CARD_B)));

        // Initialize categoryItems select items
        List<Category> cats = categoryService.findAll();
        categories = new ArrayList<SelectItem>(cats.size());
        for (Category cat : cats) {
            categories.add(new SelectItem(cat, cat.getName()));
        }

        // Initialize gender select items
        genderItems = new ArrayList<SelectItem>();
        genderItems.add(new SelectItem('f', getGenderLabel('f')));
        genderItems.add(new SelectItem('m', getGenderLabel('m')));
    }

    public List<Customer> getCustomerList() {
        if (customerList == null){
            customerList = new ArrayList<Customer>();
            customerList.addAll(customerService.findAll());
        }
        return customerList;
    }

    public SheetState getSelectedCustomer() {
        return selectedCustomer;
    }

    public void setSelectedCustomer(SheetState selectedCustomer) {
        this.selectedCustomer = selectedCustomer;
    }

    public SheetState getSelectedAddress() {
        return selectedAddress;
    }

    public void setSelectedAddress(SheetState selectedAddress) {
        this.selectedAddress = selectedAddress;
    }

    public String deleteCustomer() {
        Customer customerToDelete = getSingleSelectedCustomer();
        if (customerToDelete != null) {
            customerService.delete(customerToDelete);
            customerList.remove(customerToDelete);
        }
        newCustomer = new Customer();
        return CUSTOMER_LIST;
    }


    public String editCustomer() {
        Customer c = getSingleSelectedCustomer();
        if (c != null){
            customer = c;
            newCustomer = new Customer();
            return CUSTOMER;
        }
        return null;
    }

    private Customer getSingleSelectedCustomer() {
        if (selectedCustomer != null) {
            List<Integer> selection = selectedCustomer.getSelectedRows();
            if (selection.size() != 1 || customerList.isEmpty()) {
                createFacesMessage(FacesMessage.SEVERITY_ERROR, "Please select exactly one row.");
                return null;
            }
            return customerList.get(selection.get(0));
        }
        return null;
    }

    private void createFacesMessage(FacesMessage.Severity severity, String msg) {
        FacesMessage facesMessage = new FacesMessage(msg);
        facesMessage.setSeverity(severity);
        FacesContext.getCurrentInstance().addMessage(null, facesMessage);
    }

    public String changeCreditCardUsage() {
        return CUSTOMER;
    }

    public String createCustomer() {
        customer = new Customer();
        newCustomer = new Customer();
        return CUSTOMER;
    }

    public String showCustomer(long id) {
        return "/showCustomer.xhtml";
    }

    public String saveCustomer() {
      customerService.save(customer);
      if (customerList.contains(customer)){
          customerList.remove(customer);
      }
      customerList.add(customer);
      newCustomer = customer;
      customer = new Customer();
      return CUSTOMER_LIST;
    }

    public String cancel() {
        customer = new Customer();
        return CUSTOMER_LIST;
    }

    public String createAddress() {
        this.address = customerService.createAddress(customer);
        return ADDRESS;
    }

    public String editAddress() {
        this.address = getSingleSelectedAddress();
        if (this.address != null) {
            return ADDRESS;
        } else {
            return null;
        }
    }

    public String saveAddress() {
        customerService.saveAddress(address);
        this.address = null;
        return CUSTOMER;
    }

    public String deleteAddress() {
        Address address = getSingleSelectedAddress();
        if (address != null) {
            customerService.deleteAddress(address);
        }
        return CUSTOMER;
    }

    private Address getSingleSelectedAddress() {        
        List<Integer> selection = selectedAddress.getSelectedRows();
        if (selection.size() != 1 || addressList.isEmpty()) {
            createFacesMessage(FacesMessage.SEVERITY_ERROR, "Please select exactly one row.");
            return null;
        }
        return addressList.get(selection.get(0));
    }

    public void useCreditCardChanged(ValueChangeEvent ev) {
        Boolean useCreditCard = (Boolean) ev.getNewValue();
        if (useCreditCard != null) {
            customer.setUseCreditCard(useCreditCard);
        }
        FacesContext.getCurrentInstance().renderResponse();
    }

    public String getSelectedCreditCardType() {
        String selectedCCType = null;
        if (customer.getCreditCardType() != null) {
            selectedCCType = getCCTypeLabel(customer.getCreditCardType());
        }
        return selectedCCType;
    }

    public void validateCreditNumber(FacesContext ctx, UIComponent component,
            Object value) throws ValidatorException {
        // Only validate credit card data if user specified to use it
        CreditCardType ccType = (CreditCardType) creditCardTypeInput.getValue();
        Boolean useCC = customer.getUseCreditCard();
        if (useCC != null && useCC && ccType != null) {
            // Check credit card number
            String ccNumber = (String) value;
            int length;
            if (ccType == CreditCardType.CARD_A) {
                length = 4;
            } else {
                length = 5;
            }
            if (!ccNumber.matches("\\d{" + length + "}")) {
                FacesMessage msg = GuiUtil.getFacesMessage(
                        ctx, FacesMessage.SEVERITY_ERROR, "validateCreditCardNumber.NUMBER", length);
                throw new ValidatorException(msg);
            }
        }
    }

    public Customer getCustomer() {
        return customer;
    }

    public Customer getNewCustomer() {
        return newCustomer;
    }

    public List<SelectItem> getCreditCardTypes() {
        return this.ccTypes;
    }

    public List<SelectItem> getGenderItems() {
        return genderItems;
    }

    public UIInput getCreditCardTypeInput() {
        return this.creditCardTypeInput;
    }

    public void setCreditCardTypeInput(UIInput creditCardTypeInput) {
        this.creditCardTypeInput = creditCardTypeInput;
    }

    public Address getAddress() {
        return address;
    }

    private String getCCTypeLabel(CreditCardType type) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        String key = "credit_card_type_" + type.toString();
        return GuiUtil.getResourceText(ctx, "msgs", key);
    }

    private String getGenderLabel(char gender) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        return GuiUtil.getResourceText(ctx, "msgs", "gender_" + gender);
    }

    public boolean isNoCustomerAvailable(){
        return customerList != null && customerList.isEmpty();
    }

    public List<Address> getAddressList(){
        addressList = new ArrayList<Address>();
        Customer c = getSingleSelectedCustomer();
        if (c != null){
            addressList.addAll(c.getAddresses());
        }
        return addressList;
    }

    public List<SelectItem> getCategories() {
        return categories;
    }

    public List<Category> getPreferredCategories() {
        List<Category> cats = null;
        if (customer != null) {
           cats = new ArrayList<Category>(customer.getPreferredCategories());
        }
        return cats;
    }

    public void setPreferredCategories(List<Category> cats) {
        if (customer != null) {
           customer.setPreferredCategories(new HashSet<Category>(cats));
        }
    }

}
