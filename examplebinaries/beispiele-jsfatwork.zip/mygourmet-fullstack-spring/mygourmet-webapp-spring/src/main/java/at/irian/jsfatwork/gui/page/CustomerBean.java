package at.irian.jsfatwork.gui.page;

import at.irian.jsfatwork.domain.Address;
import at.irian.jsfatwork.service.CustomerService;
import org.apache.myfaces.orchestra.viewController.annotations.ViewController;
import org.springframework.context.annotation.Scope;

import javax.inject.Inject;
import javax.inject.Named;

@Named("customerBean")
@Scope("access")
@ViewController(viewIds = {ViewIds.EDIT_CUSTOMER, ViewIds.SHOW_CUSTOMER, ViewIds.EDIT_ADDRESS})
public class CustomerBean extends CustomerBeanBase {

    @Inject
    private CustomerService customerService;

    private boolean collapsed = false;
    private Address address;

    public String showCustomer(long id) {
        this.customer = customerService.findById(id);
        return ViewIds.SHOW_CUSTOMER;
    }

	public String saveCustomer() {
        customerService.save(customer);
		return ViewIds.SHOW_CUSTOMER;
	}

	public String createAddress() {
        this.address = customerService.createAddress(customer);
        return ViewIds.EDIT_ADDRESS;
	}

    public String editAddress(Address address) {
        this.address = address;
        return ViewIds.EDIT_ADDRESS;
    }

    public String saveAddress() {
        customerService.saveAddress(address);
        this.address = null;
        return ViewIds.SHOW_CUSTOMER;
    }

    public void deleteAddress(Address address) {
        customerService.deleteAddress(address);
    }

    public String cancelAddress() {
        this.address = null;
        return ViewIds.SHOW_CUSTOMER;
    }

    public boolean isCollapsed() {
        return collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
    }

    public Address getAddress() {
        return address;
    }

}
