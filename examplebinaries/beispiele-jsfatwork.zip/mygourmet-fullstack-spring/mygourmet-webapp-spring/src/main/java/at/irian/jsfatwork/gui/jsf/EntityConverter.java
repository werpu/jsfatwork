package at.irian.jsfatwork.gui.jsf;

import at.irian.jsfatwork.domain.BaseEntity;
import at.irian.jsfatwork.service.BaseService;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import java.io.Serializable;

public class EntityConverter implements Converter, Serializable {
    private static final long serialVersionUID = -1176470402158735L;

    public Object getAsObject(FacesContext ctx, UIComponent component, String value) {
        if (value == null || value.length() == 0) {
            return null;
        }
        long id = new Long(value);
        return service.findById(id);
    }

    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value == null) {
            return "";
        }
        return ((BaseEntity)value).getId().toString();
    }

    // Dependency injection setter
    private BaseService service;
    public void setService(BaseService service) {
        this.service = service;
    }

}
