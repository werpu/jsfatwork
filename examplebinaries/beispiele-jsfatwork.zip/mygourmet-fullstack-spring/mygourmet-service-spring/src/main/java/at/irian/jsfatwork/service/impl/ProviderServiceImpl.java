package at.irian.jsfatwork.service.impl;

import at.irian.jsfatwork.dao.CrudService;
import at.irian.jsfatwork.domain.Dish;
import at.irian.jsfatwork.domain.Order;
import at.irian.jsfatwork.domain.OrderItem;
import at.irian.jsfatwork.domain.Provider;
import at.irian.jsfatwork.service.ProviderService;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Named("providerService")
@Singleton
public class ProviderServiceImpl implements ProviderService {
    @Inject
    private CrudService crudService;

    public Provider createNew() {
        return crudService.createNew(Provider.class);
    }

    @Transactional
    public void save(Provider entity) {
        crudService.persist(entity);
    }

    @Transactional
    public void delete(Provider provider) {
        Set<Order> orders = new HashSet<Order>();
        for (Dish dish : provider.getDishes()) {
            for (OrderItem item : dish.getOrderItems()) {
                orders.add(item.getOrder());
            }
        }
        for (Order order : orders) {
            order.setCustomer(null);
            crudService.delete(order);
        }
        provider.getCategories().clear();
        crudService.delete(provider);
    }

    @Transactional(readOnly = true)
    public Provider findById(long id) {
        return crudService.findById(Provider.class, id);
    }

    @Transactional(readOnly = true)
    public List<Provider> findAll() {
        return crudService.findAll(Provider.class);
    }

}
