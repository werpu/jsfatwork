package at.irian.jsfatwork.service.impl;

import at.irian.jsfatwork.dao.CrudService;
import at.irian.jsfatwork.domain.Address;
import at.irian.jsfatwork.domain.Customer;
import at.irian.jsfatwork.domain.Order;
import at.irian.jsfatwork.service.CustomerService;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import java.util.Date;
import java.util.List;

@Named("customerService")
@Singleton
public class CustomerServiceImpl implements CustomerService {
    @Inject
    private CrudService crudService;

    public Customer createNew() {
        return crudService.createNew(Customer.class);
    }

    @Transactional
    public void save(Customer customer) {
        crudService.persist(customer);
    }

    @Transactional
    public void delete(Customer customer) {
        crudService.delete(customer);
    }

    @Transactional(readOnly = true)
    public List<Customer> findAll() {
        return crudService.findAll(Customer.class);
    }

    @Transactional(readOnly = true)
    public Customer findById(long id) {
        return crudService.findById(Customer.class, id);
    }

    public Address createAddress(Customer customer) {
        Address address = crudService.createNew(Address.class);
        address.setCustomer(customer);
        return address;
    }

    @Transactional
    public void saveAddress(Address address) {
        if (address.isTransient()) {
            crudService.persist(address);
            address.getCustomer().addAddress(address);
        }
    }

    @Transactional
    public void deleteAddress(Address address) {
        address.getCustomer().getAddresses().remove(address);
        crudService.delete(address);
    }

    public Order createOrder(Customer customer) {
        Order order = crudService.createNew(Order.class);
        order.setCustomer(customer);
        return order;
    }

    @Transactional
    public void saveOrder(Order order) {
        order.setOrderDate(new Date());
        order.getCustomer().getOrders().add(order);
        crudService.persist(order);
    }

}
