package at.irian.jsfatwork.service;

import at.irian.jsfatwork.domain.Dish;
import at.irian.jsfatwork.domain.Provider;

public interface DishService extends BaseService<Dish> {

    public Dish createNew(Provider provider);

}
